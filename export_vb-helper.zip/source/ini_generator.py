def generate_ini_text(component_paths):
    lines = []
    for key, path in component_paths.items():
        if path:  # 경로가 지정된 항목만 포함
            lines.append(f"{key}={path}")
    return "\n".join(lines)

def save_ini(text, save_path):
    with open(save_path, "w", encoding="utf-8") as f:
        f.write(text)