REQUIRED_COMPONENT_KEYS = [
    "ib", "position", "texcoord", "blend",
    "diffuse", "lightmap", "normalmap", "materialmap"
]